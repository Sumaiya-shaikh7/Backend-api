<?php
header("Content-Type: application/json");
require_once("../config/db.php");

$load_id = $_POST['load_id'];
$reference_code = $_POST['reference_code'];
$total_distance_km = $_POST['total_distance_km'];
$expected_freight = $_POST['expected_freight'];
$pickup_location = $_POST['pickup_location'];
$delivery_location = $_POST['delivery_location'];

$q = $conn->prepare("INSERT INTO After_Posting 
(load_id, reference_code, total_distance_km, expected_freight, pickup_location, delivery_location)
VALUES (?, ?, ?, ?, ?, ?)");

if ($q->execute([$load_id, $reference_code, $total_distance_km, $expected_freight, $pickup_location, $delivery_location])) {
    echo json_encode(["status" => "success", "message" => "After posting created"]);
} else {
    echo json_encode(["status" => "error", "message" => "Failed to create"]);
}
?>
