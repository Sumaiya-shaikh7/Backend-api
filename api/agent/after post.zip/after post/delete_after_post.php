<?php
header("Content-Type: application/json");
require_once("../config/db.php");

$id = $_POST['id'];

$q = $conn->prepare("DELETE FROM After_Posting WHERE id = ?");

if ($q->execute([$id])) {
    echo json_encode(["status" => "success", "message" => "Deleted"]);
} else {
    echo json_encode(["status" => "error", "message" => "Delete failed"]);
}
?>

