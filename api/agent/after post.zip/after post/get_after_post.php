<?php
header("Content-Type: application/json");
require_once("../config/db.php");

$load_id = $_GET['load_id'];

$q = $conn->prepare("SELECT * FROM After_Posting WHERE load_id = ?");
$q->execute([$load_id]);

$data = $q->fetch(PDO::FETCH_ASSOC);

if ($data) {
    echo json_encode(["status" => "success", "data" => $data]);
} else {
    echo json_encode(["status" => "error", "message" => "No data found"]);
}
?>
