<<?php
header("Content-Type: application/json");
require_once("../config/db.php");

$id = $_POST['id'];
$driver_matches = $_POST['driver_matches'];
$avg_response_minutes = $_POST['avg_response_minutes'];
$is_tracking_enabled = $_POST['is_tracking_enabled'];

$q = $conn->prepare("UPDATE After_Posting 
SET driver_matches=?, avg_response_minutes=?, is_tracking_enabled=?
WHERE id=?");

if ($q->execute([$driver_matches, $avg_response_minutes, $is_tracking_enabled, $id])) {
    echo json_encode(["status" => "success", "message" => "Updated"]);
} else {
    echo json_encode(["status" => "error", "message" => "Update failed"]);
}
?>
